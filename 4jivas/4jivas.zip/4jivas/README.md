﻿# Video Auto Splitterの使い方

![Setting](./setting-1.png)

![Scan Region](./setting-2.png)
