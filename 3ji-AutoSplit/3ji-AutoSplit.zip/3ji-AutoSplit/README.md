﻿## 設定

### 500x400

![設定](./setting.png)

### 640x480

![設定](./setting-640x480.png)
