﻿## 設定

![Setting](./setting-1.png)

![Scan Region](./setting-2.png)
